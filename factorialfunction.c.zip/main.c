#include<stdio.h>
void factorial()
{
  int i,fact=1,number;
   printf("enter the number you want factorial of");
scanf("%d",&number);
for(i=1;i<=number;i++)
{
fact = fact*i;
}
    printf("%d",fact);
}


int main()
{
    factorial();
    return 0;
}
